# 🌍 Tourism Explorer Web Application
### Cloud Computing Deployment Project

Tourism Explorer is a simple web application that allows users to explore tourist destinations, create travel plans, and leave reviews.

This project demonstrates deployment of a web application on **Amazon Web Services (AWS)** using both:

• Infrastructure as a Service (IaaS)  
• Platform as a Service (PaaS)

The system is intentionally designed to be **simple but fully functional** so that it can be:

- easily generated using **GitHub Copilot**
- easily deployed on **AWS EC2**
- easily deployed using **Elastic Beanstalk**

---

# 1. Project Overview

Tourism Explorer allows users to:

• explore destinations  
• create travel plans  
• submit reviews  

The system contains **3 main modules**, satisfying assignment requirements.

The application uses a **relational database** and implements **full CRUD functionality**.

---

# 2. Learning Objectives

This project demonstrates:

• Cloud deployment using AWS  
• Difference between IaaS and PaaS  
• Server configuration  
• Database integration  
• Full-stack web development  

---

# 3. Technology Stack

Backend

Python  
Flask Framework

Frontend

HTML5  
CSS3  
Bootstrap 5 (CDN)

Database

SQLite (Local Development + EC2 deployment)

MySQL / PostgreSQL (RDS deployment)

Cloud Platform

AWS

Services used:

Amazon EC2  
Amazon S3  
AWS Elastic Beanstalk  
Amazon RDS  

---

# 4. Application Modules

## Module 1 — User Authentication

Features:

• Register account  
• Login  
• Logout  
• Session management  

---

## Module 2 — Destination Management

Features:

• View tourist destinations  
• Add destination  
• Edit destination  
• Delete destination  

---

## Module 3 — Reviews & Travel Plans

Features:

• Leave reviews for destinations  
• View reviews  
• Create travel plans  
• Add destinations to travel plan  

---

# 5. System Architecture

User  
↓  
Web Browser  
↓  
Flask Web Application  
↓  
Database  

Two deployment environments:

EC2 Deployment (IaaS)

User → EC2 Server → Flask App → SQLite

Elastic Beanstalk Deployment (PaaS)

User → Elastic Beanstalk → Flask App → RDS Database

---

# 6. Project Structure
