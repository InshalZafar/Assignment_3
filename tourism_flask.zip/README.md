# Tourism Explorer

A Flask-based web application for exploring tourist destinations, creating travel plans, and leaving reviews.

## Setup

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Run the application:
   ```
   python app.py
   ```

3. Open http://localhost:5000 in your browser.

## Features

- User registration and login
- View, add, edit, delete destinations
- Leave and view reviews for destinations
- Create travel plans and add destinations to them

## Deployment

This application is designed for deployment on AWS EC2 and Elastic Beanstalk.